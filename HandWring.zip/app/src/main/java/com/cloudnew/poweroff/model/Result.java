package com.cloudnew.poweroff.model;

/**
 * Created by CloudNew on 2018/4/19
 * cloudnew@foxmail.com.
 */

public class Result {
    public String str;
    public int dis,index;
    public Result(String str, int dis, int index) {
        this.str = str;
        this.dis = dis;
        this.index = index;
    }
}
